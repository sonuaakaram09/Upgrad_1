module.exports.USER = 'user';
module.exports.ADMIN = 'admin';

module.exports.AUTH_TOKEN = 'x-auth-token';